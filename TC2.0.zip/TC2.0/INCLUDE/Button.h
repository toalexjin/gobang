
void triangle(int x1,int y1,int x2,int y2,int color)
{
int a;
struct fillsettingstype fillinfo;
a=getcolor();
getfillsettings(&fillinfo);
setcolor(7);
line(x1+1,y1+1,x1+1,y2-1);
line(x1+1,y2-1,x2-1,(y2+y1)/2);
line(x2-1,(y1+y2)/2,x1+1,y1+1);
setfillstyle(1,color);
floodfill(x1+3,y1+3,7);
setcolor(15);
line(x1,y1,x1,y2);
setcolor(15);
line(x1,y1,x2,(y1+y2)/2);
setcolor(8);
line(x1,y2,x2,(y1+y2)/2);
setcolor(a);
setfillstyle(fillinfo.pattern,fillinfo.color);
}


void prstriangle(int x1,int y1,int x2,int y2,int color)
{
int a;
struct fillsettingstype fillinfo;
a=getcolor();
getfillsettings(&fillinfo);

setcolor(color);
line(x1,y1,x1,y2);    /* 1 1 -1 0 */
line(x1,y1,x2,(y1+y2)/2);   /* -1 0 1 1*/
line(x1,y2,x2,(y2+y1)/2);   /*1 -1 -1 0 */

setfillstyle(1,color);
floodfill(x1+3,y1+3,color);

setcolor(8);
line(x1,y1,x1,y2);
setcolor(8);
line(x1,y1,x2,(y1+y2)/2);
setcolor(15);
line(x1,y2,x2,(y1+y2)/2);
setcolor(a);
setfillstyle(fillinfo.pattern,fillinfo.color);

}


       /***************** windows *******************/

void win3d(int x1,int y1,int x2,int y2,int wide,int border_color,int main_color,int fillstyle)
{
int a,i;
struct fillsettingstype fillinfo;
a=getcolor();
getfillsettings(&fillinfo);


x1+=wide;
x2-=wide;
y1+=wide;
y2-=wide;
setfillstyle(SOLID_FILL,7);
bar(x1,y1,x2,y2);
setcolor(15);
for(i=0;i<wide;i++)
  {
  line(x1-i,y1-i,x2+i,y1-i);
  line(x1-i,y1-i,x1-i,y2+i);
  line(x2-i-8,y1+i+8,x2-8-i,y2-8-i);
  line(x1+i+8,y2-i-8,x2-i-8,y2-i-8);
  }
 setcolor(8);
 for(i=0;i<wide;i++)
 {
 line(x2+i,y1-i,x2+i,y2+i);
 line(x1-i,y2+i,x2+i,y2+i);
 line(x1+i+8,y1+i+8,x2-i-8,y1+i+8);
 line(x1+i+8,y1+i+8,x1+i+8,y2-i-8);
 }
 setcolor(border_color);
 setlinestyle(SOLID_LINE,0,NORM_WIDTH);
 setfillstyle(fillstyle,main_color);
 bar3d(x1+3,y1+3,x2-3,y2-3,0,0);
setcolor(a);
setfillstyle(fillinfo.pattern,fillinfo.color);

 }

void prswin3d(int x1,int y1,int x2,int y2,int wide,int border_color,int main_color)
{
int a,i;
struct fillsettingstype fillinfo;
a=getcolor();
getfillsettings(&fillinfo);
x1+=wide;
x2-=wide;
y1+=wide;
y2-=wide;
setfillstyle(SOLID_FILL,7);
bar(x1,y1,x2,y2);
setcolor(8);
for(i=0;i<wide;i++)
  {
  line(x1-i,y1-i,x2+i,y1-i);
  line(x1-i,y1-i,x1-i,y2+i);
  line(x2-i-8,y1+i+8,x2-8-i,y2-8-i);
  line(x1+i+8,y2-i-8,x2-i-8,y2-i-8);
  }
 setcolor(15);
 for(i=0;i<wide;i++)
 {
 line(x2+i,y1-i,x2+i,y2+i);
 line(x1-i,y2+i,x2+i,y2+i);
 line(x1+i+8,y1+i+8,x2-i-8,y1+i+8);
 line(x1+i+8,y1+i+8,x1+i+8,y2-i-8);
 }
 setcolor(border_color);
 setlinestyle(SOLID_LINE,0,NORM_WIDTH);
 setfillstyle(1,main_color);
 bar3d(x1+3,y1+3,x2-3,y2-3,0,0);
setcolor(a);
setfillstyle(fillinfo.pattern,fillinfo.color);

 }



void box0(int x,int y,int l,int h,int color)
{
int a;
struct fillsettingstype fillinfo;
a=getcolor();
getfillsettings(&fillinfo);

   setfillstyle(1,0);
   bar(x,y,x+l,y+h);
   setcolor(7);
   rectangle(x-1,y-1,x+l,y+h);
   setcolor(15);
   line(x+2,y+2,x+l-3,y+2);
   line(x+2,y+2,x+2,y+h-3);
   line(x+3,y+3,x+l-4,y+3);
   line(x+3,y+3,x+3,y+h-4);
   setfillstyle(1,color);
   bar(x+4,y+4,x+l-5,y+h-5);
setcolor(a);
setfillstyle(fillinfo.pattern,fillinfo.color);

}
void box1(int x,int y,int l,int h,int color,int style)
{
int a;
struct fillsettingstype fillinfo;
l=l-x;
h=h-y;
a=getcolor();
getfillsettings(&fillinfo);

   setcolor(WHITE);
   setfillstyle(style,color);
   bar(x+2,y+2,x+l-2,y+h-2);
   line(x,y,x+l,y);
   line(x,y+1,x+l,y+1);
   line(x,y,x,y+h);
   line(x+1,y,x+1,y+h);
   setcolor(8);
   line(x+1,y+h,x+l,y+h);
   line(x+2,y+h-1,x+l,y+h-1);
   line(x+l,y+h,x+l,y+1);
   line(x+l-1,y+h,x+l-1,y+2);
setcolor(a);
setfillstyle(fillinfo.pattern,fillinfo.color);

}
void prsbox1(int x,int y,int l,int h)
{
int a;
struct fillsettingstype fillinfo;
l=l-x;
h=h-y;
a=getcolor();
getfillsettings(&fillinfo);

   setcolor(8);
   line(x,y,x+l,y);
   line(x,y+1,x+l,y+1);
   line(x,y,x,y+h);
   line(x+1,y,x+1,y+h);
   setcolor(WHITE);
   line(x+1,y+h,x+l,y+h);
   line(x+2,y+h-1,x+l,y+h-1);
   line(x+l,y+h,x+l,y+1);
   line(x+l-1,y+h,x+l-1,y+2);
setcolor(a);
setfillstyle(fillinfo.pattern,fillinfo.color);

}
void upbox1(int x,int y,int l,int h)
{
int a;
struct fillsettingstype fillinfo;
a=getcolor();
getfillsettings(&fillinfo);
l=l-x;
h=h-y;
   setcolor(WHITE);
   line(x,y,x+l,y);
   line(x,y+1,x+l,y+1);
   line(x,y,x,y+h);
   line(x+1,y,x+1,y+h);
   setcolor(8);
   line(x+1,y+h,x+l,y+h);
   line(x+2,y+h-1,x+l,y+h-1);
   line(x+l,y+h,x+l,y+1);
   line(x+l-1,y+h,x+l-1,y+2);
setcolor(a);
setfillstyle(fillinfo.pattern,fillinfo.color);

}
void popbox1(int x,int y,int l,int h)
{
 prsbox1(x,y,l,h);
 delay(800);
 upbox1(x,y,l,h);

}

/*void prsbox0(int x,int y,int l,int h)
{
   void *buf1,*buf2;

   buf1=malloc(imagesize(x+2,y+2,x+l-2,y+h-2));
   buf2=malloc(imagesize(x+4,y+4,x+l-5,y+h-5));
   getimage(x+2,y+2,x+l-2,y+h-2,buf1);
   getimage(x+4,y+4,x+l-5,y+h-5,buf2);
   setfillstyle(1,7);
   bar(x+1,y+1,x+l-2,y+h-2);
   putimage(x+6,y+6,buf2,COPY_PUT);
   delay(200);
   putimage(x+2,y+2,buf1,COPY_PUT);
   free(buf1);
   free(buf2);
}      */

void prsbox2(int x,int y,int l,int h)
{
int a;
struct fillsettingstype fillinfo;
a=getcolor();
getfillsettings(&fillinfo);

   setcolor(0);
   line(x+2,y+2,x+l-3,y+2);
   line(x+2,y+2,x+2,y+h-3);
   line(x+3,y+3,x+l-4,y+3);
   line(x+3,y+3,x+3,y+h-4);
   setcolor(15);
   line(x+l-2,y+h-2,x+l-2,y+3);
   line(x+l-2,y+h-2,x+2,y+h-2);
   line(x+l-3,y+h-3,x+l-3,y+4);
   line(x+l-3,y+h-3,x+3,y+h-3);
   setcolor(7);
   line(x+l-4,y+h-4,x+l-4,y+4);
   line(x+l-4,y+h-4,x+4,y+h-4);
   line(x,y,x+l,y);
   line(x,y,x,y+h);
setcolor(a);
setfillstyle(fillinfo.pattern,fillinfo.color);

}
void popup1(int x,int y,int l,int h)
{
int a;
struct fillsettingstype fillinfo;
a=getcolor();
getfillsettings(&fillinfo);

   setcolor(15);
   line(x+2,y+2,x+l-3,y+2);
   line(x+2,y+2,x+2,y+h-3);
   line(x+3,y+3,x+l-4,y+3);
   line(x+3,y+3,x+3,y+h-4);
   setcolor(0);
   line(x+l-2,y+h-2,x+l-2,y+3);
   line(x+l-2,y+h-2,x+2,y+h-2);
   line(x+l-3,y+h-3,x+l-3,y+4);
   line(x+l-3,y+h-3,x+3,y+h-3);
setcolor(a);
setfillstyle(fillinfo.pattern,fillinfo.color);

}


