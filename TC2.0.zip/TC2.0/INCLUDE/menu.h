
 /***** MENU ITEM CHECK ******/

void check1(int x1,int y1,int x2,int y2)
{
int xm,ym,i;
xm=(x2-x1)/2;
ym=(y2-y1)/2;
i=getcolor();
setcolor(15);
line(x1,y1+ym,x1+xm,y2-1);
line(x1+xm,y2-1,x2,y1);
setcolor(8);
line(x1,y1+ym+1,x1+xm,y2);
line(x1+xm,y2,x2,y1+1);
setcolor(i);
}

void check2(int x1,int y1,int x2,int y2)
{
int xm,ym,i;
xm=(x2-x1)/2;
ym=(y2-y1)/2;
i=getcolor();
setcolor(8);
line(x1,y1+ym,x1+xm,y2-1);
line(x1+xm,y2-1,x2,y1);
setcolor(15);
line(x1,y1+ym+1,x1+xm,y2);
line(x1+xm,y2,x2,y1+1);
setcolor(i);
}


     /******** MENU ITEM STRUCTURE **********/

struct item_type
{
char *caption;
int flag;
int check;
};
  /********* MENU LABLE STRUCTURE *******/
  struct label_type
  {
  int forecolor,backcolor,style,flag,wide;
  char *caption;
  };

     /******* MENU STRUCTURE ********/
struct menu_type
{
int x1,y1,x2,y2,high,wide,num,forecolor,movecolor,backcolor,position;
struct item_type item[10];
struct label_type label;
void *buffer;
};
   /******** COLOR TYPE ***********/

struct color_type
{
int fore,fill,style,back;
};

  /******* MENU INIT: X2->X1,Y2->Y1 *******/

void menuinit2(struct menu_type *a)
{
a->x1=a->x2-4-a->wide;
a->y1=a->y2-1-(3+a->high)*a->num;
a->buffer=malloc(1);
if (a->label.flag==1)
   a->x1=a->x1-a->label.wide;
}

  /******* MENU INIT: X1->X2,Y1->Y2 *******/

void menuinit1(struct menu_type *a)
{
a->x2=a->x1+4+a->wide;
a->y2=a->y1+1+(3+a->high)*a->num;
a->buffer=malloc(1);
if (a->label.flag==1)
   a->x2=a->x2+a->label.wide;
}


 /********* MENU CLEAR1 *************/
menuclear1(struct menu_type a,int flag)
{
int i,oldbackcolor;
struct fillsettingstype oldfill;
oldbackcolor=getbkcolor();
getfillsettings(&oldfill);
setfillstyle(1,oldbackcolor);
if (flag==0)
   {
   for(i=0;i<=(a.y2-a.y1);i++)
   bar(a.x1,a.y1,a.x2,a.y1+i);
   }
if (flag==1)
  {
  for(i=(a.y2-a.y1);i>=0;i--)
  bar(a.x1,a.y1+i,a.x2,a.y2);
  }
}

 /********* MENU CLEAR2 *************/
menuclear2(struct menu_type *a)
{
putimage(a->x1,a->y1,a->buffer,0);
free(a->buffer);
}

    /****** MENU UP/DOWN ******/
menuup(struct menu_type *a,int flag)
{
int i;
free(a->buffer);
a->buffer=malloc(sizeof(a->x1,a->y1,a->x2,a->y2));
getimage(a->x1,a->y1,a->x2,a->y2,a->buffer);

if (flag==0)
   {
   for(i=(a->y2-a->y1)-2;i>0;i--)
   box1(a->x1,a->y1+i,a->x2,a->y2,a->backcolor);
   }
if (flag==1)
   {
   for(i=2;i<(a->y2-a->y1)-1;i++)
   box1(a->x1,a->y1,a->x2,(a->y1+i),a->backcolor);
   }
}
 /******* MENU DRAW :CAPTION.... ********/

menudraw(struct menu_type *a)
{

int i,oldforecolor,x,y,k,l,h;
struct fillsettingstype oldfill;
struct textsettingstype oldtext;
     /*** INIT SYSTEM ***/
gettextsettings(&oldtext);
oldforecolor=getcolor();
getfillsettings(&oldfill);
setfillstyle(1,a->backcolor);

setfillstyle(1,a->backcolor);
 box1(a->x1,a->y1,a->x2,a->y2,a->backcolor);
 x=a->x1+2;
 y=a->y1+2;
if (a->label.flag!=1)
{
 for(i=0;i<a->num;i++)
    {
      bar(x,y,x+a->wide,y+a->high);
      if (i<(a->num-1))
       {
       setcolor(8);
       line(x+2,y+a->high+1,x+a->wide-1,y+a->high+1);
       setcolor(15);
       line(x+2,y+a->high+2,x+a->wide-1,y+a->high+2);
       }
  setcolor(a->forecolor);
  outtextxy(a->x2-a->wide*4/5,y+a->high*2/5,a->item[i].caption);
  if (a->item[i].flag==1)
       {
       h=a->high*1/3;
       triangle(a->x2-a->wide/6,y+h,a->x2-a->wide/6+h,y+h*2);
       }
  if (a->item[i].check==1)
   check2(x+6,y+a->high/3,x+16,y+a->high/3+12);
     y=y+a->high+3;
    }
 }
 else
  {
   x=x+a->label.wide;
   y=a->y1+2;
  for(i=0;i<a->num;i++)
    {
      bar(x,y,x+a->wide,y+a->high);
      if (i<(a->num-1))
       {
       setcolor(8);
       line(x+2,y+a->high+1,x+a->wide-1,y+a->high+1);
       setcolor(15);
       line(x+2,y+a->high+2,x+a->wide-1,y+a->high+2);
       }
       setcolor(a->forecolor);
       outtextxy(a->x2-a->wide*4/5,y+a->high*2/5,a->item[i].caption);
       if (a->item[i].flag==1)
        {
	 h=a->high*1/3;
	  triangle(a->x2-a->wide/6,y+h,a->x2-a->wide/6+h,y+h*2);

        }
  if (a->item[i].check==1)
 check2(x+6,y+a->high/3,x+16,y+a->high/3+12);
    y=y+a->high+3;
    }
   setcolor(a->label.forecolor);
   setfillstyle(a->label.style,a->label.backcolor);
  settextjustify(1,1);
   settextstyle(0,1,2);
   bar(a->x1+2,a->y1+2,a->x1+2+a->label.wide,a->y2-2);
 /**** setusercharsize(3,1,3,1);****/
   k=a->x1+a->label.wide/2+2;
   l=a->y1+(a->y2-a->y1)/2+1;
   outtextxy(k,l,a->label.caption);
   }
    settextstyle(oldtext.font,oldtext.direction,oldtext.charsize);
    settextjustify(oldtext.horiz,oldtext.vert);
    setcolor(oldforecolor);
    setfillstyle(oldfill.pattern,oldfill.color);

}

